hid_guardian
------------
.. automodule:: gremlin.hid_guardian
