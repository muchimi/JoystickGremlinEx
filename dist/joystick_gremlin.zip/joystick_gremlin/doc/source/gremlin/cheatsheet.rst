cheatsheet
----------
.. automodule:: gremlin.cheatsheet
