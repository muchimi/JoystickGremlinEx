plugin_manager
--------------
.. automodule:: gremlin.plugin_manager
