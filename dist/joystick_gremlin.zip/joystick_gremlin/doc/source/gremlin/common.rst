common
------
.. automodule:: gremlin.common
