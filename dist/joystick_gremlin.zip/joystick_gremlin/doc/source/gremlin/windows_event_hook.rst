windows_event_hook
------------------
.. automodule:: gremlin.windows_event_hook
