device_tab
----------
.. automodule:: gremlin.ui.device_tab
