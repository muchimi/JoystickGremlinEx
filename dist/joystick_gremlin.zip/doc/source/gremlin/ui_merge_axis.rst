merge_axis
----------
.. automodule:: gremlin.ui.merge_axis
