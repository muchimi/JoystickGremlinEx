event_handler
-------------
.. automodule:: gremlin.event_handler
