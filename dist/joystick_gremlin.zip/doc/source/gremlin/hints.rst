hints
-----
.. automodule:: gremlin.hints
