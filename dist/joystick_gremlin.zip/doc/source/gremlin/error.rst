error
-----
.. automodule:: gremlin.error
