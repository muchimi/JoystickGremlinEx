common
------
.. automodule:: gremlin.ui.common
