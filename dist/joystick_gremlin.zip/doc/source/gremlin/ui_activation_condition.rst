activation_condition
--------------------
.. automodule:: gremlin.ui.activation_condition
