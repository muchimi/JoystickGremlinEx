shared_state
------------
.. automodule:: gremlin.shared_state
