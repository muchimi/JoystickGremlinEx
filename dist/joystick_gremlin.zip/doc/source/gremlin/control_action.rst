control_action
--------------
.. automodule:: gremlin.control_action
