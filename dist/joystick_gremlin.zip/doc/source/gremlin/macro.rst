macro
-----
.. automodule:: gremlin.macro
