util
----
.. automodule:: gremlin.util
