user_plugin_management
----------------------
.. automodule:: gremlin.ui.user_plugin_management
