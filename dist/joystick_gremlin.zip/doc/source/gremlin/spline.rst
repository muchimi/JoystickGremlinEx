spline
------
.. automodule:: gremlin.spline
